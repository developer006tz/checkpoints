<html>
    <head>
        <title>My App</title>
    </head>
    <body>
        <h1>My App</h1>
        <p>My App is a Laravel application.</p>


        <h1>helooo laravel</h1>
    </body>
    
</html><?php /**PATH C:\SERVER\htdocs\clinic\cms\resources\views/test/index.blade.php ENDPATH**/ ?>